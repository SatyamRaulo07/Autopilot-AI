import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageSquare, Phone, Send } from 'lucide-react';

const Support = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-6">
            Need <span className="gradient-text">Help?</span>
          </h1>
          <p className="text-foreground/80 text-lg max-w-2xl mx-auto">
            Our support team is here to help you with any questions or concerns.
            Reach out to us through any of the channels below.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="glass-panel p-8">
              <h2 className="font-display text-2xl font-bold mb-6">Contact Us</h2>
              
              <div className="space-y-6">
                <ContactItem
                  icon={Phone}
                  title="Phone Support"
                  content="+1 (888) 123-4567"
                  subtitle="24/7 Enterprise Support"
                />
                <ContactItem
                  icon={Mail}
                  title="Email"
                  content="support@autopilot.ai"
                  subtitle="Response within 24 hours"
                />
                <ContactItem
                  icon={MessageSquare}
                  title="Live Chat"
                  content="Available 24/7"
                  subtitle="Instant response from our AI"
                />
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <form onSubmit={handleSubmit} className="glass-panel p-8 space-y-6">
              <h2 className="font-display text-2xl font-bold mb-6">Send us a message</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-glass px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-blue"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-glass px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-blue"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Subject</label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full bg-glass px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-blue"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={5}
                    className="w-full bg-glass px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent-blue resize-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-full font-semibold bg-gradient-to-r from-accent-blue to-accent-purple hover:opacity-90 transition-opacity duration-300 neon-glow flex items-center justify-center"
              >
                Send Message
                <Send className="ml-2 w-5 h-5" />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

const ContactItem = ({ 
  icon: Icon, 
  title, 
  content, 
  subtitle 
}: { 
  icon: any; 
  title: string; 
  content: string; 
  subtitle: string;
}) => (
  <div className="flex items-start space-x-4">
    <div className="w-12 h-12 rounded-full bg-accent-blue/20 flex items-center justify-center flex-shrink-0">
      <Icon className="w-6 h-6 text-accent-blue" />
    </div>
    <div>
      <h3 className="font-semibold mb-1">{title}</h3>
      <p className="text-foreground/80">{content}</p>
      <p className="text-sm text-foreground/60">{subtitle}</p>
    </div>
  </div>
);

export default Support;