import React from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { Settings, Download, BarChart, Users, Bell, LogOut } from 'lucide-react';

const Dashboard = () => {
  const { user, signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div className="min-h-screen pt-20">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <div className="glass-panel p-6 space-y-4">
              <div className="flex items-center space-x-4 p-4 bg-glass rounded-lg">
                <div className="w-12 h-12 rounded-full bg-accent-blue/20 flex items-center justify-center">
                  {user?.email?.[0].toUpperCase()}
                </div>
                <div>
                  <div className="font-semibold">{user?.email}</div>
                  <div className="text-sm text-foreground/60">Enterprise Plan</div>
                </div>
              </div>
              
              <nav className="space-y-2">
                <NavItem icon={Download} label="Downloads" />
                <NavItem icon={BarChart} label="Analytics" />
                <NavItem icon={Users} label="Team" />
                <NavItem icon={Bell} label="Notifications" />
                <NavItem icon={Settings} label="Settings" />
                <button
                  onClick={handleSignOut}
                  className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-glass-hover transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Sign Out</span>
                </button>
              </nav>
            </div>
          </motion.div>

          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-3 space-y-8"
          >
            <div className="glass-panel p-8">
              <h2 className="font-display text-2xl font-bold mb-6">Welcome to Your Dashboard</h2>
              <p className="text-foreground/80">
                Get started with Autopilot AI by downloading the latest version and exploring
                your enterprise features.
              </p>
              <button className="mt-6 px-8 py-4 rounded-full font-semibold bg-gradient-to-r from-accent-blue to-accent-purple hover:opacity-90 transition-opacity duration-300 neon-glow inline-flex items-center">
                <Download className="w-5 h-5 mr-2" />
                Download Autopilot AI
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="glass-panel p-6">
                <h3 className="font-display text-xl font-bold mb-4">Quick Stats</h3>
                <div className="space-y-4">
                  <StatItem label="Tasks Automated" value="128" />
                  <StatItem label="Time Saved" value="47 hours" />
                  <StatItem label="Active Devices" value="3" />
                </div>
              </div>

              <div className="glass-panel p-6">
                <h3 className="font-display text-xl font-bold mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  <ActivityItem
                    title="New Device Connected"
                    time="2 hours ago"
                  />
                  <ActivityItem
                    title="Workflow Automated"
                    time="5 hours ago"
                  />
                  <ActivityItem
                    title="Settings Updated"
                    time="1 day ago"
                  />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

const NavItem = ({ icon: Icon, label }: { icon: any; label: string }) => (
  <button className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-glass-hover transition-colors">
    <Icon className="w-5 h-5" />
    <span>{label}</span>
  </button>
);

const StatItem = ({ label, value }: { label: string; value: string }) => (
  <div className="flex justify-between items-center">
    <span className="text-foreground/60">{label}</span>
    <span className="font-semibold">{value}</span>
  </div>
);

const ActivityItem = ({ title, time }: { title: string; time: string }) => (
  <div className="flex justify-between items-center">
    <span>{title}</span>
    <span className="text-sm text-foreground/60">{time}</span>
  </div>
);

export default Dashboard;