import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Code, Globe, Users } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen pt-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-6">
            About <span className="gradient-text">Autopilot AI</span>
          </h1>
          <p className="text-foreground/80 text-lg max-w-2xl mx-auto">
            We are redefining productivity with cutting-edge AI that automates your workflow effortlessly.
            Experience the future of intelligent assistance, built for professionals, businesses, and tech enthusiasts.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {[
            {
              icon: Brain,
              title: 'Advanced AI',
              description: 'Cutting-edge machine learning algorithms power our intelligent automation.',
            },
            {
              icon: Code,
              title: 'Smart Integration',
              description: 'Seamlessly connects with your existing tools and workflows.',
            },
            {
              icon: Globe,
              title: 'Global Scale',
              description: 'Enterprise-ready infrastructure serving clients worldwide.',
            },
            {
              icon: Users,
              title: 'Team Focus',
              description: 'Built for collaboration and team productivity enhancement.',
            },
          ].map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-panel p-6 text-center"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-accent-blue/20 flex items-center justify-center">
                <item.icon className="w-8 h-8 text-accent-blue" />
              </div>
              <h3 className="font-display text-xl font-bold mb-2">{item.title}</h3>
              <p className="text-foreground/70">{item.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="glass-panel p-8 md:p-12 max-w-4xl mx-auto"
        >
          <h2 className="font-display text-3xl font-bold mb-6 text-center">
            Our Vision
          </h2>
          <p className="text-foreground/80 text-lg leading-relaxed mb-8">
            At Autopilot AI, we envision a future where artificial intelligence seamlessly integrates into your daily workflow, 
            enhancing productivity and creativity while eliminating repetitive tasks. Our mission is to make advanced AI 
            technology accessible to everyone, from individual professionals to large enterprises.
          </p>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="glass-panel p-6">
              <h3 className="font-display text-xl font-bold mb-3">Our Mission</h3>
              <p className="text-foreground/70">
                To revolutionize productivity through intelligent automation, making advanced AI accessible and practical for everyone.
              </p>
            </div>
            <div className="glass-panel p-6">
              <h3 className="font-display text-xl font-bold mb-3">Our Values</h3>
              <p className="text-foreground/70">
                Innovation, accessibility, and user-centric design drive everything we do at Autopilot AI.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default About;