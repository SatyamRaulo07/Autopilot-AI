import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Calendar, Mail, Terminal } from 'lucide-react';

const features = [
  {
    icon: Terminal,
    title: 'Automated Task Handling',
    description: 'Let AI handle your repetitive tasks while you focus on what matters most.',
  },
  {
    icon: Brain,
    title: 'Voice Commands',
    description: 'Control your computer naturally with advanced voice recognition technology.',
  },
  {
    icon: Calendar,
    title: 'Smart Scheduling',
    description: 'AI-powered calendar management that optimizes your time automatically.',
  },
  {
    icon: Mail,
    title: 'Email & Data Processing',
    description: 'Intelligent email management and data processing capabilities.',
  },
];

const Features = () => {
  return (
    <section className="py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
            Supercharge Your <span className="gradient-text">Productivity</span>
          </h2>
          <p className="text-foreground/80 text-lg max-w-2xl mx-auto">
            Discover how Autopilot AI transforms your daily workflow with powerful features
            designed for the future of work.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="glass-panel p-6 hover:scale-105 transition-transform duration-300"
            >
              <feature.icon className="w-12 h-12 text-accent-blue mb-4" />
              <h3 className="font-display text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-foreground/70">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;