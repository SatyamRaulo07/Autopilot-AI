import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  const scrollToPricing = () => {
    const pricingSection = document.getElementById('pricing');
    pricingSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-accent-blue/10 via-accent-purple/5 to-transparent" />
      
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold mb-6">
              <span className="gradient-text">Autopilot AI</span>
              <br />
              Your Smartest Digital Assistant
            </h1>
            <p className="text-foreground/80 text-lg md:text-xl mb-8 max-w-2xl">
              Experience the future of productivity with our cutting-edge AI assistant.
              Automate tasks, process data, and streamline your workflow effortlessly.
            </p>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <button
                onClick={scrollToPricing}
                className="neon-glow inline-flex items-center px-8 py-4 rounded-full bg-gradient-to-r from-accent-blue to-accent-purple text-lg font-semibold hover:opacity-90 transition-opacity duration-300"
              >
                Get Started Now
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              <a
                href="/about"
                className="inline-flex items-center px-8 py-4 rounded-full bg-glass hover:bg-glass-hover transition-colors duration-300"
              >
                Learn More
              </a>
            </motion.div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="relative"
          >
            <div className="aspect-square rounded-full bg-accent-blue/20 animate-float">
              <img
                src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&w=800"
                alt="AI Assistant Visualization"
                className="w-full h-full object-cover rounded-full mix-blend-screen"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -inset-4 bg-gradient-to-r from-accent-blue/30 to-accent-purple/30 rounded-full blur-3xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;