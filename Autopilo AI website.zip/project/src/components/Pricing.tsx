import React from 'react';
import { motion } from 'framer-motion';
import { Check, Crown, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const features = [
  'Advanced AI Task Automation',
  'Natural Language Voice Commands',
  'Smart Calendar Management',
  'Intelligent Email Processing',
  'Custom Workflow Automation',
  'Multi-Device Synchronization',
  'Priority 24/7 Support',
  'API Access for Custom Integration',
  'Secure Cloud Backup',
  'Advanced Analytics Dashboard'
];

const Pricing = () => {
  const navigate = useNavigate();

  return (
    <section id="pricing" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-accent-purple/5 via-accent-blue/5 to-transparent" />
      
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
            Enterprise <span className="gradient-text">Solution</span>
          </h2>
          <p className="text-foreground/80 text-lg max-w-2xl mx-auto">
            Experience the most advanced AI automation platform designed for
            enterprise-scale operations and professional teams.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="glass-panel p-12 relative border-2 border-accent-purple"
          >
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <span className="bg-accent-purple text-white px-6 py-2 rounded-full text-sm font-semibold">
                Enterprise Grade
              </span>
            </div>
            
            <div className="flex items-center justify-center mb-8">
              <Crown className="w-16 h-16 text-accent-blue" />
            </div>
            
            <div className="text-center mb-8">
              <h3 className="font-display text-3xl font-bold mb-4">
                Enterprise Plan
              </h3>
              <div className="mb-4">
                <span className="text-5xl font-bold">$499</span>
                <span className="text-foreground/60">/month</span>
              </div>
              <p className="text-foreground/80 text-lg">
                Complete AI automation solution for enterprise teams and organizations
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6 mb-12">
              {features.map((feature) => (
                <div key={feature} className="flex items-center">
                  <Check className="w-5 h-5 text-accent-blue mr-3 flex-shrink-0" />
                  <span className="text-foreground/80">{feature}</span>
                </div>
              ))}
            </div>
            
            <button
              onClick={() => navigate('/auth')}
              className="w-full py-5 px-8 rounded-full font-semibold text-lg bg-gradient-to-r from-accent-blue to-accent-purple hover:opacity-90 transition-opacity duration-300 neon-glow flex items-center justify-center"
            >
              Get Enterprise Access
              <ArrowRight className="ml-2 w-6 h-6" />
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;