import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Brain, Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, signOut } = useAuth();
  const location = useLocation();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <nav className="fixed w-full z-50 glass-panel">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Brain className="w-8 h-8 text-accent-blue" />
            <span className="font-display text-xl font-bold gradient-text">Autopilot AI</span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            <NavLink to="/about" active={location.pathname === '/about'}>About</NavLink>
            <NavLink to="/pricing" active={location.pathname === '/pricing'}>Pricing</NavLink>
            <NavLink to="/support" active={location.pathname === '/support'}>Support</NavLink>
            {user ? (
              <>
                <Link
                  to="/dashboard"
                  className="px-6 py-2 rounded-full bg-glass hover:bg-glass-hover transition-colors duration-300"
                >
                  Dashboard
                </Link>
                <button
                  onClick={handleSignOut}
                  className="px-6 py-2 rounded-full bg-gradient-to-r from-accent-blue to-accent-purple hover:opacity-90 transition-opacity duration-300"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/auth"
                  className="px-6 py-2 rounded-full bg-glass hover:bg-glass-hover transition-colors duration-300"
                >
                  Login
                </Link>
                <Link
                  to="/auth"
                  className="px-6 py-2 rounded-full bg-gradient-to-r from-accent-blue to-accent-purple hover:opacity-90 transition-opacity duration-300"
                >
                  Get Started
                </Link>
              </>
            )}
          </div>
          
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-white/10">
            <div className="flex flex-col space-y-4">
              <MobileNavLink 
                to="/about" 
                active={location.pathname === '/about'}
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </MobileNavLink>
              <MobileNavLink 
                to="/pricing" 
                active={location.pathname === '/pricing'}
                onClick={() => setIsMenuOpen(false)}
              >
                Pricing
              </MobileNavLink>
              <MobileNavLink 
                to="/support" 
                active={location.pathname === '/support'}
                onClick={() => setIsMenuOpen(false)}
              >
                Support
              </MobileNavLink>
              {user ? (
                <>
                  <Link
                    to="/dashboard"
                    onClick={() => setIsMenuOpen(false)}
                    className="px-6 py-2 rounded-full bg-glass hover:bg-glass-hover transition-colors duration-300 text-center"
                  >
                    Dashboard
                  </Link>
                  <button
                    onClick={() => {
                      handleSignOut();
                      setIsMenuOpen(false);
                    }}
                    className="px-6 py-2 rounded-full bg-gradient-to-r from-accent-blue to-accent-purple hover:opacity-90 transition-opacity duration-300 text-center"
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/auth"
                    onClick={() => setIsMenuOpen(false)}
                    className="px-6 py-2 rounded-full bg-glass hover:bg-glass-hover transition-colors duration-300 text-center"
                  >
                    Login
                  </Link>
                  <Link
                    to="/auth"
                    onClick={() => setIsMenuOpen(false)}
                    className="px-6 py-2 rounded-full bg-gradient-to-r from-accent-blue to-accent-purple hover:opacity-90 transition-opacity duration-300 text-center"
                  >
                    Get Started
                  </Link>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

const NavLink = ({ to, active, children }: { to: string; active: boolean; children: React.ReactNode }) => (
  <Link
    to={to}
    className={`text-foreground/80 hover:text-foreground transition-colors duration-300 ${
      active ? 'text-foreground font-semibold' : ''
    }`}
  >
    {children}
  </Link>
);

const MobileNavLink = ({ 
  to, 
  active,
  children, 
  onClick 
}: { 
  to: string;
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) => (
  <Link
    to={to}
    onClick={onClick}
    className={`text-foreground/80 hover:text-foreground transition-colors duration-300 block px-4 py-2 ${
      active ? 'text-foreground font-semibold' : ''
    }`}
  >
    {children}
  </Link>
);

export default Navbar;